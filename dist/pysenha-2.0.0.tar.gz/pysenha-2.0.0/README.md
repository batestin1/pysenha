
<h1 align="center">
<img src="https://img.shields.io/static/v1?label=PYSENHA%20POR&message=Bates&color=7159c1&style=flat-square&logo=ghost"/>
<h3> <p align="center">PYSENHA </p> </h3>
<h3> <p align="center"> ================= </p> </h3>
>> <h3> Resume </h3>
<p> gerador de senha </p>
>> <h3> How install </h3>
```
pip install pysenha
```
>> <h3> How Works </h3>
```
pysenha(velhasenha)
```
    